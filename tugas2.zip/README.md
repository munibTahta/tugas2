#TUGASMOBILE02<br>
Tugas 02 Weather <br> 
Pemrograman Perangkat Moblie
<br><br>
Nama : Munib Tahta
<br>
Nim  : 2015150120
<br>
Kls  : 02
<br><br>
QR CODE APP:
<br><br><img src="qrcode.png">
<br><br>
Screenshot App<br>
<img height="50%"  width="50%" src="1.png">
